export class Locations{
    locationid: number;
    location_name: string;
    area: string;
    slots: number;
}