package com.carParking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RemotehiringApplication {

	public static void main(String[] args) {
		SpringApplication.run(RemotehiringApplication.class, args);
	}

}
